if __name__ == '__main__':
    from IPython.testing import iptestcontroller
    iptestcontroller.main()
